import React from 'react';
import Router from './router/router'
import './App.scss';

function App() {
  return (
    <div className="hh-box">
      {/* <header className="App-logo">logo</header> */}
      <Router />
    </div>
  );
}

export default App;